
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const IrfanComputersApp());
}

class IrfanComputersApp extends StatelessWidget {
  const IrfanComputersApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Irfan Computers',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B4DBB)),
      scaffoldBackgroundColor: const Color(0xFFF6F8FC),
      useMaterial3: true,
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const HomeShell(),
  );
}

class AppDb {
  AppDb._(); static final instance = AppDb._(); Database? _db;
  Future<Database> get database async => _db ??= await openDatabase(
    join(await getDatabasesPath(), 'irfan_computers.db'), version: 1,
    onCreate: (db, v) async {
      await db.execute('CREATE TABLE jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, phone TEXT, device TEXT NOT NULL, fault TEXT, board TEXT, dcReading TEXT, voltages TEXT, notes TEXT, status TEXT NOT NULL, total REAL NOT NULL DEFAULT 0, advance REAL NOT NULL DEFAULT 0, createdAt TEXT NOT NULL)');
      await db.execute('CREATE TABLE stock(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0)');
    });
  Future<List<Map<String,dynamic>>> jobs() async => (await database).query('jobs', orderBy:'id DESC');
  Future<int> addJob(Map<String,dynamic> x) async => (await database).insert('jobs', x);
  Future<int> updateStatus(int id, String status) async => (await database).update('jobs', {'status':status}, where:'id=?', whereArgs:[id]);
  Future<int> deleteJob(int id) async => (await database).delete('jobs', where:'id=?', whereArgs:[id]);
  Future<List<Map<String,dynamic>>> stock() async => (await database).query('stock', orderBy:'name');
  Future<int> addStock(Map<String,dynamic> x) async => (await database).insert('stock', x);
}

class HomeShell extends StatefulWidget { const HomeShell({super.key}); @override State<HomeShell> createState()=>_HomeShellState(); }
class _HomeShellState extends State<HomeShell> {
  int index=0;
  final pages = const [Dashboard(), JobsPage(), StockPage(), ReportsPage()];
  @override Widget build(BuildContext c)=>Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(
      selectedIndex:index, onDestinationSelected:(i)=>setState(()=>index=i),
      destinations: const [
        NavigationDestination(icon:Icon(Icons.home_outlined), selectedIcon:Icon(Icons.home), label:'Home'),
        NavigationDestination(icon:Icon(Icons.build_outlined), selectedIcon:Icon(Icons.build), label:'Jobs'),
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined), selectedIcon:Icon(Icons.inventory_2), label:'Stock'),
        NavigationDestination(icon:Icon(Icons.bar_chart_outlined), selectedIcon:Icon(Icons.bar_chart), label:'Reports'),
      ],
    ),
    floatingActionButton: index==1 ? FloatingActionButton.extended(
      onPressed:() async { await Navigator.push(c, MaterialPageRoute(builder:(_)=>const NewJobPage())); setState((){}); },
      icon:const Icon(Icons.add), label:const Text('New Job')
    ):null,
  );
}

Widget header(String title, String subtitle)=>Padding(
  padding:const EdgeInsets.fromLTRB(20,18,20,12),
  child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
    Text(title, style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800,color:Color(0xFF0B2D62))),
    const SizedBox(height:4), Text(subtitle, style:TextStyle(color:Colors.grey.shade600))
  ])
);

class Dashboard extends StatefulWidget { const Dashboard({super.key}); @override State<Dashboard> createState()=>_DashboardState(); }
class _DashboardState extends State<Dashboard> {
  @override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,dynamic>>>(
    future:AppDb.instance.jobs(), builder:(c,s){
      final j=s.data??[]; final pending=j.where((e)=>e['status']!='Completed').length;
      final ready=j.where((e)=>e['status']=='Completed').length;
      final income=j.fold<double>(0,(a,e)=>a+(e['total'] as num).toDouble());
      final balance=j.fold<double>(0,(a,e)=>a+((e['total'] as num)-(e['advance'] as num)).toDouble());
      return ListView(children:[
        Container(
          padding:const EdgeInsets.all(22),
          decoration:const BoxDecoration(gradient:LinearGradient(colors:[Color(0xFF083C91),Color(0xFF1168D8)]),
            borderRadius:BorderRadius.only(bottomLeft:Radius.circular(28),bottomRight:Radius.circular(28))),
          child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('IRFAN COMPUTERS',style:TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.w900)),
            SizedBox(height:5),Text('Repair • Service • Trust',style:TextStyle(color:Colors.white70,fontSize:15)),
            SizedBox(height:18),Text('Assalam-o-Alaikum, Irfan 👋',style:TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w600)),
          ]),
        ),
        Padding(padding:const EdgeInsets.all(16),child:GridView.count(
          crossAxisCount:2, shrinkWrap:true, physics:const NeverScrollableScrollPhysics(), mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.35,
          children:[
            stat('Pending Jobs','$pending',Icons.pending_actions,const Color(0xFFFFE7E5),const Color(0xFFC62828)),
            stat('Ready Jobs','$ready',Icons.task_alt,const Color(0xFFE8F5E9),const Color(0xFF2E7D32)),
            stat('Total Billing','Rs ${income.toStringAsFixed(0)}',Icons.payments,const Color(0xFFE3F2FD),const Color(0xFF1565C0)),
            stat('Balance Due','Rs ${balance.toStringAsFixed(0)}',Icons.account_balance_wallet,const Color(0xFFFFF3E0),const Color(0xFFEF6C00)),
          ],
        )),
        const Padding(padding:EdgeInsets.fromLTRB(20,6,20,10),child:Text('Recent Jobs',style:TextStyle(fontSize:19,fontWeight:FontWeight.w800))),
        ...j.take(5).map((e)=>jobTile(c,e,()=>setState((){}))),
        const SizedBox(height:20)
      ]);
    });
}

Widget stat(String t,String v,IconData i,Color bg,Color fg)=>Container(
  padding:const EdgeInsets.all(16), decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(18)),
  child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
    Icon(i,color:fg),Text(v,style:TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:fg)),Text(t,style:const TextStyle(fontWeight:FontWeight.w600))
  ])
);

class JobsPage extends StatefulWidget { const JobsPage({super.key}); @override State<JobsPage> createState()=>_JobsPageState(); }
class _JobsPageState extends State<JobsPage> {
  String q='';
  @override Widget build(BuildContext c)=>Column(children:[
    header('Repair Jobs','Customer devices, diagnosis & payments'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:TextField(
      onChanged:(v)=>setState(()=>q=v.toLowerCase()), decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search customer, phone or device...')
    )),
    const SizedBox(height:12),
    Expanded(child:FutureBuilder<List<Map<String,dynamic>>>(future:AppDb.instance.jobs(),builder:(c,s){
      final all=s.data??[]; final j=all.where((e)=>('${e['customer']} ${e['phone']} ${e['device']}'.toLowerCase()).contains(q)).toList();
      if(j.isEmpty)return const Center(child:Text('No repair jobs yet.\nTap “New Job” to add one.',textAlign:TextAlign.center));
      return RefreshIndicator(onRefresh:()async=>setState((){}),child:ListView(children:j.map((e)=>jobTile(c,e,()=>setState((){}))).toList()));
    }))
  ]);
}

Widget jobTile(BuildContext c,Map<String,dynamic> e,VoidCallback refresh)=>Padding(
  padding:const EdgeInsets.fromLTRB(16,0,16,10),
  child:Card(child:ListTile(
    contentPadding:const EdgeInsets.all(14),
    leading:CircleAvatar(backgroundColor:const Color(0xFFE8F0FF),child:Text('${e['id']}',style:const TextStyle(fontWeight:FontWeight.bold))),
    title:Text(e['device'],style:const TextStyle(fontWeight:FontWeight.w800)),
    subtitle:Text('${e['customer']} • ${e['fault']}\nBalance: Rs ${((e['total'] as num)-(e['advance'] as num)).toStringAsFixed(0)}'),
    isThreeLine:true, trailing:Chip(label:Text(e['status'],style:const TextStyle(fontSize:11))),
    onTap:() async { await Navigator.push(c,MaterialPageRoute(builder:(_)=>JobDetails(job:e))); refresh(); },
  ))
);

class NewJobPage extends StatefulWidget { const NewJobPage({super.key}); @override State<NewJobPage> createState()=>_NewJobPageState(); }
class _NewJobPageState extends State<NewJobPage> {
  final customer=TextEditingController(), phone=TextEditingController(), device=TextEditingController(),
    fault=TextEditingController(), board=TextEditingController(), dc=TextEditingController(), volts=TextEditingController(),
    notes=TextEditingController(), total=TextEditingController(), advance=TextEditingController();
  String status='In Progress';
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('New Repair Job')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      section('Customer & Device'),
      field(customer,'Customer Name *',Icons.person),field(phone,'Phone Number',Icons.phone),
      field(device,'Device / Model *',Icons.laptop),field(fault,'Fault / Problem',Icons.warning_amber),
      section('Technical Information'),
      field(board,'Board Number / Motherboard',Icons.memory),field(dc,'DC Reading (e.g. 0.108A)',Icons.electric_bolt),
      field(volts,'Voltages (3V, 5V, VCORE, RAM...)',Icons.speed),field(notes,'Work Done / Technical Notes',Icons.notes,max:4),
      section('Payment'),
      field(total,'Estimated / Total Charges (Rs)',Icons.payments,number:true),
      field(advance,'Advance Paid (Rs)',Icons.account_balance_wallet,number:true),
      DropdownButtonFormField<String>(initialValue:status,items:['In Progress','Diagnosing','Waiting Parts','Completed'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(v)=>setState(()=>status=v!),decoration:const InputDecoration(labelText:'Status')),
      const SizedBox(height:18),
      FilledButton.icon(onPressed:()async{
        if(customer.text.trim().isEmpty||device.text.trim().isEmpty){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Customer name and device are required')));return;}
        await AppDb.instance.addJob({
          'customer':customer.text.trim(),'phone':phone.text.trim(),'device':device.text.trim(),'fault':fault.text.trim(),
          'board':board.text.trim(),'dcReading':dc.text.trim(),'voltages':volts.text.trim(),'notes':notes.text.trim(),
          'status':status,'total':double.tryParse(total.text)??0,'advance':double.tryParse(advance.text)??0,
          'createdAt':DateTime.now().toIso8601String()
        });
        if(c.mounted)Navigator.pop(c);
      },icon:const Icon(Icons.save),label:const Padding(padding:EdgeInsets.all(14),child:Text('SAVE REPAIR JOB'))),
      const SizedBox(height:30)
    ])
  );
  Widget field(TextEditingController x,String label,IconData icon,{int max=1,bool number=false})=>Padding(
    padding:const EdgeInsets.only(bottom:12),child:TextField(controller:x,maxLines:max,keyboardType:number?TextInputType.number:null,
      decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon))));
  Widget section(String s)=>Padding(padding:const EdgeInsets.fromLTRB(2,10,2,10),child:Text(s,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:Color(0xFF0B4DBB))));
}

class JobDetails extends StatefulWidget { final Map<String,dynamic> job; const JobDetails({super.key,required this.job}); @override State<JobDetails> createState()=>_JobDetailsState(); }
class _JobDetailsState extends State<JobDetails> {
  late Map<String,dynamic> j=Map.of(widget.job);
  @override Widget build(BuildContext c){
    final bal=(j['total'] as num)-(j['advance'] as num);
    return Scaffold(appBar:AppBar(title:Text('Job #${j['id']}'),actions:[
      IconButton(onPressed:()=>makeInvoice(j,false),icon:const Icon(Icons.picture_as_pdf)),
      PopupMenuButton<String>(onSelected:(v)async{
        if(v=='delete'){await AppDb.instance.deleteJob(j['id']);if(c.mounted)Navigator.pop(c);}
        else{await AppDb.instance.updateStatus(j['id'],v);setState(()=>j['status']=v);}
      },itemBuilder:(_)=>[
        ...['In Progress','Diagnosing','Waiting Parts','Completed'].map((x)=>PopupMenuItem(value:x,child:Text('Mark $x'))),
        const PopupMenuDivider(),const PopupMenuItem(value:'delete',child:Text('Delete Job'))
      ])
    ]),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF0B4DBB),Color(0xFF1676E8)]),borderRadius:BorderRadius.circular(20)),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(j['device'],style:const TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.w900)),
          const SizedBox(height:5),Text('${j['customer']} • ${j['phone']}',style:const TextStyle(color:Colors.white70)),
          const SizedBox(height:12),Chip(label:Text(j['status']))
        ])),
      const SizedBox(height:14),
      info('Fault / Problem',j['fault']),info('Board Number',j['board']),info('DC Reading',j['dcReading']),
      info('Voltages',j['voltages']),info('Technical Notes',j['notes']),
      const SizedBox(height:8),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        money('Total Charges',(j['total'] as num).toDouble()),money('Advance Paid',(j['advance'] as num).toDouble()),
        const Divider(),money('Remaining Balance',bal.toDouble(),bold:true)
      ]))),
      const SizedBox(height:14),
      FilledButton.icon(onPressed:()=>makeInvoice(j,false),icon:const Icon(Icons.picture_as_pdf),label:const Padding(padding:EdgeInsets.all(13),child:Text('PREVIEW / PRINT INVOICE'))),
      const SizedBox(height:10),
      OutlinedButton.icon(onPressed:()=>makeInvoice(j,true),icon:const Icon(Icons.share),label:const Padding(padding:EdgeInsets.all(13),child:Text('SHARE PDF INVOICE'))),
    ]));
  }
  Widget info(String a,dynamic b)=>Card(child:ListTile(title:Text(a,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text((b??'').toString().isEmpty?'—':b.toString())));
  Widget money(String a,double b,{bool bold=false})=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
    Text(a,style:TextStyle(fontWeight:bold?FontWeight.w900:FontWeight.w500)),Text('Rs ${b.toStringAsFixed(0)}',style:TextStyle(fontWeight:bold?FontWeight.w900:FontWeight.w600))
  ]));
}

Future<void> makeInvoice(Map<String,dynamic> j,bool share) async {
  final doc=pw.Document(); final bal=(j['total'] as num)-(j['advance'] as num);
  doc.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:const pw.EdgeInsets.all(30),build:(ctx)=>pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
    pw.Container(color:PdfColors.blue900,padding:const pw.EdgeInsets.all(18),child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
      pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Text('IRFAN COMPUTERS',style:pw.TextStyle(color:PdfColors.white,fontSize:22,fontWeight:pw.FontWeight.bold)),pw.Text('Repair - Service - Trust',style:const pw.TextStyle(color:PdfColors.white))]),
      pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.end,children:[pw.Text('INVOICE',style:pw.TextStyle(color:PdfColors.white,fontSize:20,fontWeight:pw.FontWeight.bold)),pw.Text('# IC-2026-${j['id'].toString().padLeft(5,'0')}',style:const pw.TextStyle(color:PdfColors.white))])
    ])),
    pw.SizedBox(height:20),
    pw.Row(children:[pw.Expanded(child:pdfBox('CUSTOMER DETAILS',['Name: ${j['customer']}','Phone: ${j['phone']}'])),pw.SizedBox(width:12),pw.Expanded(child:pdfBox('DEVICE DETAILS',['Device: ${j['device']}','Fault: ${j['fault']}']))]),
    pw.SizedBox(height:16),
    pw.Text('WORK / TECHNICAL DETAILS',style:pw.TextStyle(fontWeight:pw.FontWeight.bold,color:PdfColors.blue900)),
    pw.Divider(),
    pw.Text('Board: ${j['board']}\nDC Reading: ${j['dcReading']}\nVoltages: ${j['voltages']}\nNotes: ${j['notes']}'),
    pw.Spacer(),
    pw.Container(padding:const pw.EdgeInsets.all(14),decoration:pw.BoxDecoration(border:pw.Border.all(color:PdfColors.grey400)),child:pw.Column(children:[
      rowPdf('Total Charges','Rs ${(j['total'] as num).toStringAsFixed(0)}'),
      rowPdf('Advance Paid','Rs ${(j['advance'] as num).toStringAsFixed(0)}'),
      pw.Divider(),rowPdf('Remaining Balance','Rs ${bal.toStringAsFixed(0)}',bold:true),
    ])),
    pw.SizedBox(height:18),
    pw.Text('Warranty: 7 Days Checking Warranty',style:pw.TextStyle(fontWeight:pw.FontWeight.bold)),
    pw.SizedBox(height:6),pw.Text('Note: Physical damage, liquid damage and burnt items are not covered under warranty.'),
    pw.SizedBox(height:24),pw.Center(child:pw.Text('Thank you for choosing Irfan Computers')),
    pw.SizedBox(height:8),pw.Center(child:pw.Text('WhatsApp: 0303-9814008 - Rexcity, Faisalabad'))
  ])));
  final bytes=await doc.save();
  if(share){
    final f=File(join(await getDatabasesPath(),'invoice_${j['id']}.pdf'));await f.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(f.path)],text:'Irfan Computers Invoice #${j['id']}');
  } else {
    await Printing.layoutPdf(onLayout:(_)=>bytes,name:'Irfan Computers Invoice');
  }
}
pw.Widget pdfBox(String t,List<String> lines)=>pw.Container(padding:const pw.EdgeInsets.all(12),decoration:pw.BoxDecoration(border:pw.Border.all(color:PdfColors.grey400)),child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
  pw.Text(t,style:pw.TextStyle(fontWeight:pw.FontWeight.bold,color:PdfColors.blue900)),pw.SizedBox(height:7),...lines.map((x)=>pw.Padding(padding:const pw.EdgeInsets.only(bottom:3),child:pw.Text(x)))
]));
pw.Widget rowPdf(String a,String b,{bool bold=false})=>pw.Padding(padding:const pw.EdgeInsets.symmetric(vertical:5),child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
  pw.Text(a,style:pw.TextStyle(fontWeight:bold?pw.FontWeight.bold:pw.FontWeight.normal)),pw.Text(b,style:pw.TextStyle(fontWeight:bold?pw.FontWeight.bold:pw.FontWeight.normal))
]));

class StockPage extends StatefulWidget { const StockPage({super.key}); @override State<StockPage> createState()=>_StockPageState(); }
class _StockPageState extends State<StockPage> {
  @override Widget build(BuildContext c)=>Column(children:[
    header('Stock Management','Parts, quantity & purchase value'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>add(c),icon:const Icon(Icons.add),label:const Text('Add Stock Item')))),
    const SizedBox(height:12),
    Expanded(child:FutureBuilder<List<Map<String,dynamic>>>(future:AppDb.instance.stock(),builder:(c,s){final x=s.data??[];if(x.isEmpty)return const Center(child:Text('No stock items yet.'));
      return ListView(children:x.map((e)=>Padding(padding:const EdgeInsets.fromLTRB(16,0,16,10),child:Card(child:ListTile(
        leading:const CircleAvatar(child:Icon(Icons.memory)),title:Text(e['name'],style:const TextStyle(fontWeight:FontWeight.w800)),
        subtitle:Text('Stock: ${e['qty']} pcs'),trailing:Text('Rs ${(e['price'] as num).toStringAsFixed(0)}')
      )))).toList());}))
  ]);
  Future<void> add(BuildContext c)async{
    final n=TextEditingController(),q=TextEditingController(),p=TextEditingController();
    await showDialog(context:c,builder:(d)=>AlertDialog(title:const Text('Add Stock Item'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'Item name')),const SizedBox(height:8),
      TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantity')),const SizedBox(height:8),
      TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Unit price'))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancel')),FilledButton(onPressed:()async{
      if(n.text.trim().isNotEmpty)await AppDb.instance.addStock({'name':n.text.trim(),'qty':int.tryParse(q.text)??0,'price':double.tryParse(p.text)??0});
      if(d.mounted)Navigator.pop(d);
    },child:const Text('Save'))]));
    setState((){});
  }
}

class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,dynamic>>>(
  future:AppDb.instance.jobs(),builder:(c,s){final j=s.data??[];final total=j.fold<double>(0,(a,e)=>a+(e['total'] as num).toDouble());
  final paid=j.fold<double>(0,(a,e)=>a+(e['advance'] as num).toDouble());final done=j.where((e)=>e['status']=='Completed').length;
  return ListView(children:[header('Reports & Profit','Quick business overview'),
    Padding(padding:const EdgeInsets.all(16),child:GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.25,children:[
      stat('Total Billing','Rs ${total.toStringAsFixed(0)}',Icons.receipt_long,const Color(0xFFE8F5E9),const Color(0xFF2E7D32)),
      stat('Advance Received','Rs ${paid.toStringAsFixed(0)}',Icons.payments,const Color(0xFFE3F2FD),const Color(0xFF1565C0)),
      stat('Jobs Completed','$done',Icons.task_alt,const Color(0xFFF3E5F5),const Color(0xFF7B1FA2)),
      stat('Total Jobs','${j.length}',Icons.build,const Color(0xFFFFF3E0),const Color(0xFFEF6C00)),
    ])),
    const Padding(padding:EdgeInsets.all(20),child:Text('Version 1 report shows billing and job activity. Expense ledger and true net-profit calculation can be added in the next upgrade.',style:TextStyle(color:Colors.black54)))
  ]);}));
}
