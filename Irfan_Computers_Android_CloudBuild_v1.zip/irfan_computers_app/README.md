# Irfan Computers App v1

Professional offline-first Android repair shop management app.

Included:
- Premium dashboard
- Repair job entry
- Customer/device records
- Technical notes: board number, DC reading, voltages
- Job status tracking
- Payment, advance and balance
- Search
- Stock management
- Reports overview
- Professional A4 PDF invoice
- Print preview
- PDF share to WhatsApp/other apps
- Local SQLite database: no monthly server fee

Build:
1. Install Flutter stable.
2. flutter pub get
3. flutter run
4. flutter build apk --release

APK output:
build/app/outputs/flutter-apk/app-release.apk

Shop details:
Irfan Computers
0303-9814008
Rexcity, Faisalabad

Note: This is the working source project. APK compilation needs Flutter + Android SDK, which is not installed in the current execution environment.
